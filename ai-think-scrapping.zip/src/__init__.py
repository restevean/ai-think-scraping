"""AI THINK Scrapping - Web scraper for collecting conversations and opinions."""

__version__ = "0.1.0"
__author__ = "Developer"
